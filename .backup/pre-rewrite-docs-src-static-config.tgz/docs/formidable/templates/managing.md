---
title: Managing templates
sidebar_position: 10
description: Creating, editing and syncing the six kinds of template Formidable uses.
keywords:
  - formidable
  - templates
  - sync
  - expressionengine
---

# Managing templates

**Templates** in the control panel is where markup lives — the form's,
each fieldtype's, and the emails your workflows send.

## The six types

| Type | What it renders |
| --- | --- |
| Form | A whole form — the wrapper, the field loop, the buttons |
| Fieldtype | One kind of field, for every field of that kind |
| Fieldtype Group | A family of fieldtypes, for any that has no template of its own |
| Notification | An email a workflow sends |
| Notification Header | A fragment above a notification body |
| Notification Footer | A fragment below it |

The type is chosen when the template is created and **cannot be changed
afterwards**. It decides where the template is stored, listed and looked
up — changing it would move the template to a different listing, a
different directory and a different resolution chain, while leaving a
file behind at the old path. Create a new template and delete the old
one; it is the same operation without the ambiguity.

## Creating one is two steps

**Step one** names the template — type, name, handle, description — and
chooses what it starts from:

- a **Fieldtype** or **Fieldtype Group** template picks the fieldtype it
  is for
- a **Form** or **Notification** template picks a shipped template to
  base itself on, or starts empty

**Step two** is the editor, already holding that markup.

The two steps exist because the first decides what the second contains.
An editor rendered before the choice was made would open empty and then
be contradicted a moment later.

For a fieldtype template, step two opens with whatever that field renders
**today** — following the same chain the front end does. If the fieldtype
has no template of its own you get its group's markup, which is what you
were actually looking at.

That starting point is a **copy to change, not a link**. It is shown
rather than stored until you save, so a template you create and abandon
leaves nothing behind.

## The editor

The body field is a code editor with syntax highlighting, line numbers
and bracket matching. The same editor appears wherever markup is edited —
a fieldtype's templates in the Registry, and the HTML field's content.

## Which template wins

Nothing you create can be overwritten by an update, and nothing you
create pins you to old markup. They are different layers.

For a field, Formidable takes the **first** of these that is not empty:

1. A template you created, bound to that field's fieldtype
2. A template you created, bound to that fieldtype's group
3. The inline template on the fieldtype
4. The inline template on the fieldtype group
5. The shipped file for that fieldtype
6. The shipped file for its group

**An empty template means "inherit", not "render nothing".** Half the
fieldtypes ship nothing of their own precisely so they fall through to
their group. Clearing a template is how you go back to inheriting.

See [Concepts](/getting-started/concepts) for the form-template chain and
the reasoning behind both.

## Templates on disk

Every template is written to a file as well as the database:

```
system/user/templates/formidable/
├── forms/<handle>.html
├── fieldtypes/<handle>.html
├── fieldtypes/groups/<handle>.html
├── notifications/<handle>.html
├── notifications/headers/<handle>.html
└── notifications/footers/<handle>.html
```

The handle becomes the filename, which is why handles are restricted to
letters, numbers, underscores and hyphens.

**The database is what renders.** The files exist so templates can be
committed, diffed and reviewed alongside the rest of a site.

### Sync

**Templates → Sync** reports where the two have diverged:

| State | Meaning |
| --- | --- |
| `same` | The file and the template match |
| `database_changed` | Edited here, not yet written out |
| `file_changed` | The file was edited outside the control panel |
| `conflict` | Both changed — neither can be applied without losing the other |
| `missing` | The file was exported once and is no longer there |
| `never_exported` | No file has ever been written for this template |

Conflicts are **reported, not resolved**. Picking a winner automatically
means silently discarding somebody's work.

`missing` never deletes the template. Deleting is a control panel
action; a file disappearing is a bad deploy or a stray clean, and that
must not destroy the row.

Comparison is against the **last synced copy**, not file-versus-database
directly. A two-way compare can only say the two differ; the third
point is what identifies *which side moved*, which is the whole question.
Bodies are trimmed before hashing, so opening a file and saving it
untouched does not report as changed.

:::warning
If your site's short name is `formidable`, sync is disabled — the site's
own template directory would collide with Formidable's. Rename the site,
or nothing is exported.
:::

## Starter templates

Five form templates ship with the addon — `bootstrap`, `full`,
`material`, `tailwind`, `vanilla` — plus `default`, the markup a form
falls back to when nothing else is chosen.

They work without being copied. Selecting **Bootstrap** on a form renders
the shipped file immediately; create a template with the handle
`bootstrap` and yours takes over. A starter that had to be copied before
it meant anything would be a worse starting point than none.
