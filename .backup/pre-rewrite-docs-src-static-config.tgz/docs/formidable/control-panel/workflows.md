---
title: Workflows
sidebar_position: 20
description: What happens after a submission — emails, webhooks and third-party connections, run conditionally.
keywords:
  - formidable
  - workflows
  - notifications
  - webhooks
  - expressionengine
---

# Workflows

A workflow is a thing that happens **after** a submission. A form can have
any number of them, each independently enabled, and each free to decide
for itself whether this particular submission is one it cares about.

Storing a submission and acting on it are separate. A form with storage
turned off still runs its workflows — which is how you send a
notification without keeping anyone's personal data.

## When a workflow runs

| Event | Fires on |
| --- | --- |
| Submission created | A new submission only |
| Submission updated | An existing one being changed |
| Created or updated | Either |

## Running one conditionally

Every workflow has its own condition builder. Left empty it runs on
every matching event; given conditions it runs only when the submission
satisfies them.

This is how "email the sales team, but only when Enquiry Type is
Wholesale" is expressed — two workflows on one form, each with its own
condition, rather than one workflow with branching logic inside it.

## Actions

### Email

One recipient list, with a **To / Cc / Bcc** column per row. It used to
be three separate lists, which made "add this address as a Cc" a decision
about which table to scroll to rather than a property of the row.

The message itself comes from one of two places:

- **From a template** — pick a notification template. Edit it once, and
  every workflow using it changes.
- **Custom** — write the subject and body on the workflow itself.

Choosing a template **replaces** the inline configuration rather than
merging with it. A workflow that once had a custom body still has that
body stored; merging would resurrect fields the author believes they have
stopped using, and the subject they can no longer see would be the one
that sends.

Both routes offer the same fields — from name, from address, reply-to,
subject, header, footer and body — because they come from one definition.
A setting added to one is a setting added to both.

Uploaded files can be attached to the email.

:::tip
Headers and footers are their own template types, so a signature or a
legal footer is written once and shared. See
[Managing templates](../templates/managing.md).
:::

Emails are sent as HTML with a plain-text alternative generated from it.
You write one body; recipients whose client refuses HTML still get
something readable.

### Webhook

Posts the submission to a URL.

A **secret** may be set. When it is, the request is signed so the
receiving end can verify the payload came from your site and was not
altered — worth setting for anything that acts on the data rather than
merely logging it.

### Connection

Sends the submission to a third-party service. Formidable ships
connections for:

Campaign Monitor · Constant Contact · Dotdigital · HubSpot · Mailchimp ·
Salesforce

A connection workflow has three parts:

1. **The connection** — the configured account, set up under
   **Connections**
2. **The target** — which list, audience or object to send to
3. **The mapping** — which form field feeds which remote field

The mapping is per workflow, so the same connection can feed a newsletter
list from one form and a CRM object from another.

## Order and failure

Workflows run after the submission is stored. A workflow that fails does
not roll back the submission — the answer is kept, and losing a
visitor's data because a third-party API was briefly unavailable would be
the worse outcome.

## What is not here yet

Custom workflow actions are on the [roadmap](/getting-started/roadmap).
Today the three actions above are the whole set; connections are
pluggable, actions are not.
