---
title: Submissions
sidebar_position: 30
description: Reading, filtering, saving views of and exporting what people sent.
keywords:
  - formidable
  - submissions
  - saved views
  - export
  - expressionengine
---

# Submissions

## Always one form at a time

Submissions are reached from the **submission count on the Forms
listing**, not from the sidebar. There is no "all submissions" screen,
and that is deliberate.

The filters on this screen are built from the fields of the form being
viewed. Two unrelated forms can both have a field called **Name** that
means a different thing. A table mixing them would have columns that are
true for some rows and misleading for others, and filters that silently
match nothing.

Arriving without a form redirects to the Forms listing, which is where
you pick one.

## The filter panel

One panel, one **Apply**, covering four things:

| Control | What it decides |
| --- | --- |
| Conditions | Which submissions |
| Columns | Which fields are shown |
| Per page | How many rows |
| Saved views | All three at once |

They are together because they all answer the same question — *how am I
looking at this list* — and a separate column picker would mean pressing
two controls before seeing one result.

Conditions use the same builder as everywhere else in Formidable: nested
groups, and/or, one operator set per fieldtype. See
[Concepts](/getting-started/concepts).

The filter is remembered **per form**, so narrowing one form's
submissions and then opening another does not carry the first form's
criteria over.

## Saved views

A view stores the conditions, the visible columns, the page size and the
sort. Name it and it appears in the dropdown.

**Views belong to the person who made them.** They are not shared, and
not part of the form's configuration — one member's "Unread, this week,
three columns" is a working habit rather than a site setting.

One view can be marked **default**. It applies when you arrive at the
screen fresh; it does not apply when you have just submitted a filter,
because that would throw away the criteria you were building.

Save and Apply share one submit, so what gets saved is what is on the
screen. A separate Save button would mean everyone eventually saves the
*previous* filter.

## Editing a submission

The **Manage** column carries the edit link. It is always there — the
column picker cannot offer it and a saved view cannot drop it, because a
listing whose only route into a row could be switched off would strand
every row on the screen. It is not part of the export either.

There is no separate read-only view. The edit screen *is* the view: two
renderings of the same answers are two things that can disagree.

**One page, with a heading per form page.** A submission is a record
being corrected, not a form being filled — so there is one save, one
validation pass, and browser find reaches every field. A one-page form
gets no heading at all.

Each field renders as the control its fieldtype calls for. Fields that
**store nothing** are not shown: a Submit button, an HTML block, a
Captcha. There is no answer to edit, and being asked to prove you are
not a robot in order to fix a typo would be absurd.

Encrypted fields are decrypted into the box and re-encrypted on save.

**Files and signatures can be removed but not replaced.** Uploading
through this screen would mean re-running the upload pipeline — and
every check in it — from somewhere that is not the submission pipeline.
Replace a file through the file manager.

**Status** is on the same form, alongside the submission's name.

### Workflows

Saving fires the form's **Submission Updated** workflows, which may
email the person who submitted. A toggle on the form turns that off for
one save — for the correction that should not notify anybody.

Nothing fires when nothing changed. Opening a submission and pressing
Save is a common way to leave the screen, and it should not send anyone
a notification saying so.

### What survives an edit

An answer belonging to a field **since removed from the form** is kept.
The screen cannot show it, so it writes back what it rendered and leaves
the rest alone rather than rebuilding the record from today's fields.

An answer that is **no longer one of the choices** — a channel entry
unpublished, a list edited — stays selected and is marked as such.
Dropping it would silently substitute the first option the next time
anybody saved.

## Export

**Export** streams the form's submissions as CSV: the submission's own
columns, then one per field handle.

Encrypted values are decrypted in the export. This is an authenticated
control panel route, and an export of ciphertext would not be an export.

The export is scoped to the same one form for the same reason the
listing is.

## On the front end

Submissions can also be read in templates with
[`{exp:formidable:submissions}`](../tags/submissions.md), which shares
the query this screen uses.
