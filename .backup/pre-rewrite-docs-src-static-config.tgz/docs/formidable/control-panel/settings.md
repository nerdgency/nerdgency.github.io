---
title: Settings
sidebar_position: 10
description: The settings a form carries, the site-wide defaults beneath them, and how a template can override either.
keywords:
  - formidable
  - settings
  - configuration
  - expressionengine
---

# Settings

Most of what a form does can be set in the control panel rather than on
the tag. The point is that a template can be as short as:

```
{exp:formidable:form form_handle="contact"}
```

and still return somewhere sensible on success and on failure, on the
grid your site uses, with a success message the client can edit
themselves.

## Two places, one set of settings

**Configuration** holds the site-wide defaults. **Form → Settings** holds
each form's own. They are the same list of settings, deliberately — a
form only needs to say the things that differ from the site.

**Empty means inherit.** Clearing a box returns that form to the site
default, rather than setting the value to nothing. A site that has never
opened Configuration falls back to what ships.

## How a value is decided

Four layers, most specific first. The first one that is not empty wins:

| # | Layer | Where |
| --- | --- | --- |
| 1 | The tag parameter | Your template, this render only |
| 2 | The form's setting | **Form → Settings** |
| 3 | The site-wide setting | **Configuration** |
| 4 | The shipped default | Formidable |

This applies to every setting that has a tag parameter, including:

| Setting | Parameter | Default |
| --- | --- | --- |
| Return To | `return=` | The page the form is on |
| Return To On Error | `return_on_error=` | The page the form is on |
| Template Columns | `template_columns=` | `12` |
| Success Message | `success_message=` | From the language file |
| Form Template | `template=` | Formidable's built-in markup |

:::tip
The parameter's name and the setting's name are the same string on
purpose. `return=` and the **Return To** field are one thing, so a
template and a control panel field cannot drift into describing
different things.
:::

## Overriding anything for one render

Layer 1 has a second spelling that reaches **every** setting on the
form — including those with no parameter of their own:

```
{exp:formidable:form form_handle="contact"
  form:setting:return="/thanks"
  form:setting:enable_storage="no"}
```

`form:setting:NAME` and the dedicated parameter sit at the same level, so
use whichever reads better. A name Formidable does not recognise is
ignored rather than reported — check the spelling against the setting if
one appears to do nothing.

## Where a submission goes

**Return To** accepts a path on your own site. It also accepts two
tokens, substituted after a successful submission:

```
return="thanks/SUBMISSION_HANDLE"
```

| Token | Becomes |
| --- | --- |
| `SUBMISSION_HANDLE` | The stored submission's handle |
| `SUBMISSION_ID` | Its numeric id |

Return targets are checked against an allowlist of hosts before the
visitor is sent anywhere. A URL pointing off-site is refused rather than
followed — an unchecked redirect target is an open redirect, and a form
is exactly the sort of thing people probe for one.

### Returning to the form's own page

Leaving **Return To** empty sends the visitor back to the page they
submitted from. That used to be indistinguishable from a first visit;
the form now flashes a success state, so the page can say something.
See [after a successful submission](../tags/form.md).

## Storage and privacy

| Setting | What it does |
| --- | --- |
| Enable Storage | Whether submissions are stored at all |
| Store Submission Data | Store the answers, or only the fact of a submission |
| Submission Prefix | Prepended to generated submission handles |

A form with storage off still runs its workflows — the email is sent,
nothing is kept. That is the combination to reach for when you want a
notification without holding personal data.

## Spam

| Setting | What it does |
| --- | --- |
| Enable Honeypot | A hidden field a bot fills in and a person does not |
| Enable JS Honeypot | A second check that JavaScript ran |
| Disable Submit On Process | Prevents a double submission on slow connections |

A caught submission is reported to the sender as a success. Telling a bot
it was caught tells whoever wrote the bot how to avoid the trap next
time.

CAPTCHA is a **fieldtype** rather than a setting — add a Captcha or
Turnstile field to the form.

## Submission limits

A form can stop accepting submissions, with its own message for each
reason. Both the limit and the message it shows live on the form, so
"closed" reads as something deliberate rather than an error.
