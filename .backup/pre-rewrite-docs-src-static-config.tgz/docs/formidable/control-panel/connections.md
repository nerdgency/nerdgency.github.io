---
title: Connections
sidebar_position: 40
description: Credentials for the outside services Formidable talks to, and the two things a connection can do.
keywords:
  - formidable
  - connections
  - mailchimp
  - turnstile
  - expressionengine
---

# Connections

A **connection** is one configured account with an outside service —
credentials, stored once, used by anything that needs them.

Credentials live here rather than on the workflow or field that uses
them so a rotated API key is changed in one place. A form's workflow
names a connection; it does not carry a key.

## Two kinds, and the difference matters

| | **Push** | **Verify** |
| --- | --- | --- |
| Runs | After a submission is accepted | During validation, before it is |
| Can reject a submission | No | Yes |
| Failure means | Logged, submission kept | The visitor is told, submission refused |
| Used by | A workflow | A field |

That split is why they are separate. A push failure must never lose a
submission — a CRM being briefly unreachable is not the visitor's
problem, and unwinding an accepted submission over it would be the worse
outcome. A verify failure must be able to refuse, because refusing is
the entire point of a captcha.

### Push connections

Campaign Monitor · Constant Contact · Dotdigital · HubSpot · Mailchimp ·
Salesforce

Used from a **Connection** workflow action. See
[Workflows](./workflows.md) for the target and field mapping.

### Verify connections

Cloudflare Turnstile · hCaptcha

A verify connection is used by adding the matching **field** to a form.
There is no captcha setting to turn on — the field is the switch. Its
processor calls the connection during validation, and the submission
fails if the check does.

Turnstile has a fieldtype. **hCaptcha ships as a provider only** — the
credentials and the verify call are there, but no field yet wires them
to a form.

EE's own `captcha` fieldtype is separate from both, and needs no
connection.

## Setting one up

Each provider renders its own settings form — an API key here, an
account id and a data centre there — because "credentials" is not one
shape across six services.

Fields marked secret are **encrypted at rest**. They are write-only in
the interface: you can replace one, not read it back.

## Adding a provider

Providers are **code, not registry rows**. A settings schema is data, but
what to do with a submission — which endpoint, which payload shape, how
to read the response — is not.

Third-party providers register through a config override:

```php
$config['formidable_connection_providers'] = [
    \Acme\Formidable\Providers\MyCrm::class,
];
```

A provider implements `ProviderInterface` for identity and its settings
schema, then **whichever capability fits**: `PushProviderInterface` for
send, `VerifyProviderInterface` for verify, or both. A verify-only
provider does not carry a no-op `send()` to satisfy an interface it has
no use for.
