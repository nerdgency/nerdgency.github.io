---
id: capture
title: Capture
sidebar_label: Capture
sidebar_position: 20
description: Wrap an HTML form you already wrote and Formidable builds the form behind it.
keywords:
  - formidable
  - capture
  - migration
  - expressionengine
---

# `{exp:formidable:capture}`

Wrap a form you already wrote:

```html
{exp:formidable:capture form_handle="contact"}
  <form method="post" action="{captured_action_url}">
    {captured_meta}

    <label for="name">Name</label>
    <input type="text" name="name" id="name" required>

    <label for="email">Email</label>
    <input type="email" name="email" id="email" required>

    <button type="submit">Send</button>
  </form>
{/exp:formidable:capture}
```

Formidable reads that markup, creates a form called `contact` with a
text field and an email field, and hands the markup straight back. The
page renders exactly what you wrote.

## What it is for

The form tag asks you to build the form in the control panel and then
write a template against it. Capture inverts that: **the markup is the
source**, and the form is derived from it.

Two situations want this.

**Migrating.** A site with forty hand-written forms does not have to be
rebuilt to start collecting submissions in Formidable. Wrap each one,
and the storage, validation, workflows and submission listings arrive
without the markup changing.

**Markup you are not giving up.** Some forms are a design artefact —
built to a spec, with attributes and structure that a generated template
would have to reproduce exactly. Capture leaves them alone.

## Making it submit through Formidable

Two variables do this:

| Variable | Where it goes |
| --- | --- |
| `{captured_action_url}` | The `<form action="">` |
| `{captured_meta}` | Inside the `<form>` |

`{captured_meta}` is the signed payload — which form this is, and where
to return to. It is signed rather than plain because a form id and a
return URL posted back as ordinary hidden inputs would let anyone else
choose both.

Without these two the form still renders and still captures; it just
posts wherever it did before.

## Parameters

| Parameter | Default | What it does |
| --- | --- | --- |
| `form_handle=` | — | Required. `handle=` and `name=` are also accepted |
| `form_name=` | from the handle | Used only when the form is created |
| `sync=` | `report` | See below |
| `fallback_fieldtype=` | `text` | Used when nothing scores |
| `ignore=` | — | Pipe-separated handles never turned into fields |
| `return=` | the current page | Where a submission goes |
| `return_on_error=` | the current page | Where a failed one goes |
| `prefix=` | — | Variable prefix, as on the form tag |
| `debug=` | off | Turns soft failures into errors |

### `sync=`

| Value | Behaviour |
| --- | --- |
| `report` | Parse and report drift; do not change the form |
| `update` | Also create added fields and update modified ones |
| `off` | No parsing at all — look the form up and render |

**`sync="off"` is the production setting** once a form is captured.
Parsing markup that has not changed to reach a conclusion already
reached is work every page view pays for.

Even without it, byte-identical markup skips DOM parsing entirely via a
checksum, so leaving capture on is not as expensive as it sounds.

### `ignore=`

```
ignore="newsletter|hp_check"
```

Ignored inputs still render and still submit. They are simply never
turned into fields — which is what you want for a honeypot, or for an
input that belongs to something other than this form.

### Forcing a fieldtype

```
field:phone:fieldtype="tel"
```

Overrides the matcher for one handle.

## How a field is matched

Each control is scored against **every fieldtype in your registry** —
there is no hardcoded list, so a fieldtype you added is a candidate on
the same terms as one that ships.

| Score | For |
| --- | --- |
| +100 | The handle matches the input type or the tag name |
| +80 | The fieldtype's storage input equals the input type |
| +60 | Its storage inputs include the input type |
| +40 | The storage engine agrees with the shape — a `<select>` against the options engine, a file input against the files engine |
| +20 | General engine affinity — the inputs engine for any `<input>` |
| −50 | A contradiction, such as an options control against a non-options engine |

Highest wins; ties break on registry order. Anything scoring zero or
less falls back to `fallback_fieldtype=`. If that handle does not exist
either, the field is **skipped** and reported rather than guessed at.

HTML5 validation attributes are mapped onto rules where a matching rule
handle exists — `required`, `minlength`, `pattern` and the rest arrive
as real validation rather than as browser-only hints.

Attributes are split as they are read: ones matching a registered field
attribute go into the field's attribute bag, the rest are kept as extras.
Nothing you wrote is discarded.

## Reporting drift

Capture compares the markup to the form on every parse and reports what
moved:

| Variable | Contains |
| --- | --- |
| `{captured_form_id}` `{captured_form_handle}` `{captured_form_name}` | The form |
| `{captured_created}` | The form did not exist and was created |
| `{captured_changed}` | Anything at all differs |
| `{captured_added}` | Handles in the markup but not the form |
| `{captured_removed}` | Handles in the form but not the markup |
| `{captured_modified}` | Handles whose type or attributes changed |
| `{captured_skipped}` | Handles no fieldtype could be matched to |
| `{captured_synced}` | Handles actually written, under `sync="update"` |

All the lists are pipe-separated, and all of them work in conditionals:

```
{if captured_skipped}
  <!-- {captured_skipped} -->
{/if}
```

**Removed fields are reported and never deleted**, even under
`sync="update"`. A field removed from a template still has submissions
against it, and a template edit is not a decision to destroy them.

There is also a CLI report, which is the better place to look at this on
a real site:

```
php system/ee/eecli.php formidable:capture-status --form=contact
```

Add `--json` for something to pipe.

## Only a Super Admin captures

Capture writes to the database. Public traffic must never trigger that —
a template on a public page, parsed by every visitor, would otherwise be
a way to create forms and fields from outside.

So parsing happens **only for a signed-in Super Admin**. Everyone else
gets the `sync="off"` path: the form is looked up, the markup renders,
submissions work.

A staging environment can opt out:

```php
$config['formidable_capture_public'] = 'y';
```

Do not set this in production. It is there so an automated environment
can capture without a session, and for nothing else.

## Errors

Capture exposes the same error variables the form tag does — the wrapped
form has to be able to show validation failures:

```
{if form_has_errors}
  <ul {error_list_attributes}>
    {form_errors}
      <li {error_item_attributes}>{error_name}: {error_message}</li>
    {/form_errors}
  </ul>
{/if}
```

`{error:HANDLE}` and `{value:HANDLE}` are available for placing a message
beside its input and repopulating after a failure:

```html
<input type="email" name="email" value="{value:email}">
{if error:email}<span class="error">{error:email}</span>{/if}
```

## Captured forms are locked in the control panel

A captured form's **fields cannot be created, edited or reordered in the
control panel.** The markup is the source; a control panel edit would be
silently overwritten by the next parse, or would silently diverge from
what the page actually renders.

Statuses, settings, submissions and workflows all work normally. Only
field editing is blocked.

To take over a form in the control panel, **convert** it. Nothing is
rewritten — captured fields are already stored in builder shape, so the
builder simply unlocks. There is no route back, so switch the template
to `sync="off"` (or to `{exp:formidable:form}`) at the same time, or the
markup will keep trying to drive fields the builder now owns.

**Recapture** does the opposite: it clears the stored checksum so the
next parse re-reads the markup in full. Useful when the fast path is
convinced nothing changed and you know otherwise. The control panel
cannot parse template HTML itself, so this arms the next front-end parse
rather than doing the work.

## Going to production

1. Capture with `sync="update"` while building, as a Super Admin.
2. Check `{captured_skipped}` is empty, or force those with
   `field:HANDLE:fieldtype=`.
3. Point the form at `{captured_action_url}` and drop in
   `{captured_meta}`.
4. Set `sync="off"`.

Step four is the one that gets forgotten. Nothing breaks without it —
it is just parsing work on every render that nothing acts on.
