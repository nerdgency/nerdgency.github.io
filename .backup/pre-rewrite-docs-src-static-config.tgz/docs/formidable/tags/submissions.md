---
id: submissions
title: Submissions
sidebar_label: Submissions
sidebar_position: 30
description: List, filter and page through a form's submissions on the front end, or fetch them as JSON.
keywords:
  - formidable
  - submissions tag
  - expressionengine
toc_max_heading_level: 3
---

# Submissions

Lists the submissions a form has collected, or one of them.

```html
{exp:formidable:submissions form_handle="contact_us" limit="10"}
    <article>
        <h3>{name}</h3>
        <p>{your_field_handle}</p>
        <time>{created_at format="%Y-%m-%d"}</time>
    </article>
    {if no_results}<p>Nothing yet.</p>{/if}
{/exp:formidable:submissions}
```

Each field's answer is available under **its own handle**, not the
`field_id_N` key it is stored under. Renaming a field renames the
variable; the stored data is untouched.

## The tag trusts your template

A template is written by a developer, so this tag does what its
parameters say — including when they say nothing. **Without
`member_id=`, it lists every member's submissions.**

That is the right default for a staff dashboard and the wrong one for a
member area, and only your template knows which it is:

```html
{exp:formidable:submissions form_handle="support" member_id="{logged_in_member_id}"}
```

Wrap member-facing listings in `{if logged_in}` as you would any other
personal data.

## Parameters

| Parameter | Description |
| --- | --- |
| `form_handle=` | The form to list. `form_id=` also accepted. |
| `submission_handle=` | One submission, by its public token. |
| `member_id=` | Limit to one member's own submissions. |
| `status=` | Pipe-separated status handles: `status="new\|read"`. |
| `view=` | A saved view's id — applies its criteria, sort and page size. |
| `limit=` | Default 25, capped at 500. |
| `offset=` | For paging. |
| `orderby=` | `created_at`, `updated_at`, `name`, `status` or `id`. |
| `sort=` | `asc` or `desc` (default). |

An unknown `form_handle=` lists nothing rather than everything.

Where a parameter and a saved view disagree, the parameter wins — `view="3"
limit="5"` shows five rows. The view supplies the criteria, which is the
part a template cannot express.

## Variables

| Variable | Description |
| --- | --- |
| `{id}` | Sequential id. Prefer `{handle}` anywhere public. |
| `{handle}` | The submission's public token. |
| `{name}` | Its display name. |
| `{status}` / `{status_handle}` | Its status. |
| `{member_id}` | Who submitted it, or 0. |
| `{created_at}` / `{updated_at}` | Timestamps; use `format=`. |
| `{count}` / `{absolute_count}` | Position in this page / overall. |
| `{total_results}` | How many match, ignoring the limit. |
| `{no_results}` | Rendered when nothing matches. |
| `{your_field_handle}` | One per field of the form. |

## JSON

`{exp:formidable:submissions_url}` returns a URL that serves the same
list as JSON — for a dashboard that polls, or a table that pages without
reloading.

```html
<div data-src="{exp:formidable:submissions_url form_handle="support" member_id="{logged_in_member_id}"}"></div>
```

**The tag is the authorisation, not the URL.** Everything deciding which
submissions come back is sealed into a signed payload when the template
renders; the endpoint reads nothing from its query string but `page`. A
URL emitted with `member_id=` only ever returns that member's
submissions, however the URL is edited afterwards.

It takes the same `form_handle=`, `form_id=`, `view=`, `member_id=` and
`status=` parameters. Without a valid payload the endpoint returns
`403` and no rows.

```json
{
  "form_id": 4,
  "page": 1,
  "perpage": 25,
  "total": 112,
  "submissions": [ ... ]
}
```

Append `&page=2` to page through it.

## Saved views

A saved view is created on the Submissions screen in the control panel:
a named set of filter criteria, visible columns, page size and sort,
stored against one form and one member. `view=` applies its criteria,
page size and sort — the columns are a control-panel display choice and
have no meaning in a template, where you write the markup.

Because a view is scoped to a form, `view=` naming one that belongs to a
different form is ignored rather than applied.
